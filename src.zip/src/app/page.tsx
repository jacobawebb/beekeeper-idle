import GameRoot from "@/game/GameRoot";

export default function Home() {
  return <GameRoot />;
}
